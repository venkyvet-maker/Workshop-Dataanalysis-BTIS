# ================================================================
# Alambadi cattle data: Machine-learning workshop script
# Source workflow adapted from "Alambadi script.docx".
#
# PURPOSE
# Predict body weight (BW or Weight) from morphometric measurements,
# compare regression algorithms, interpret errors and feature importance.
#
# HOW TO RUN
# 1. Put this script and Alambadi.csv in the same folder.
# 2. Open this file in RStudio and run the whole script.
# 3. If the first two columns are identifiers, keep DROP_FIRST_TWO <- TRUE.
#    Change it to FALSE if those columns are actual measurements.
# 4. Check the printed target/predictor names before interpreting results.
#
# IMPORTANT TEACHING NOTES
# - Dataset audit for the supplied Alambadi.csv: 44 animals, 17 columns,
#   no missing values; target is BW. AN is an identifier; Sex is retained.
# - The hold-out test set is kept out of feature selection and tuning.
# - Tree-based models do not require min-max scaling; SVM and neural
#   network use preprocessing estimated inside cross-validation.
# - Results depend on sample size, data quality, split, and tuning.
# ================================================================

options(stringsAsFactors = FALSE)
set.seed(123)

# --------------------------- 0. Settings --------------------------
DATA_FILE <- "Alambadi.csv"
OUTPUT_DIR <- "Alambadi_ML_results"
TRAIN_PROP <- 0.80
CV_FOLDS <- 5
DROP_FIRST_TWO <- FALSE  # corrected for supplied CSV: exclude AN only; retain Sex
RUN_BORUTA <- TRUE       # set FALSE to skip Boruta feature selection
RUN_MLP <- TRUE
RUN_SVM <- TRUE
RUN_MARS <- TRUE

if (!file.exists(DATA_FILE)) {
  stop("Cannot find '", DATA_FILE, "'. Put Alambadi.csv in the working directory, ",
       "or set DATA_FILE to its full path. Current directory: ", getwd())
}
if (!dir.exists(OUTPUT_DIR)) dir.create(OUTPUT_DIR, recursive = TRUE)

# Install missing packages only when needed.
required <- c("caret", "ggplot2", "randomForest", "rpart", "xgboost")
optional <- c("Boruta", "nnet", "kernlab", "earth")
install_if_missing <- function(pkgs) {
  missing <- pkgs[!vapply(pkgs, requireNamespace, logical(1), quietly = TRUE)]
  if (length(missing)) {
    message("Installing required package(s): ", paste(missing, collapse = ", "))
    install.packages(missing, repos = "https://cloud.r-project.org")
  }
}
install_if_missing(required)
if (RUN_BORUTA) install_if_missing("Boruta")
if (RUN_MLP) install_if_missing("nnet")
if (RUN_SVM) install_if_missing("kernlab")
if (RUN_MARS) install_if_missing("earth")

suppressPackageStartupMessages({
  library(caret)
  library(ggplot2)
  library(randomForest)
  library(rpart)
  library(xgboost)
})

# --------------------------- 1. Read data -------------------------
dat <- read.csv(DATA_FILE, check.names = FALSE, na.strings = c("", "NA", "NaN"))
if (nrow(dat) < 20) warning("Small dataset: performance estimates may be unstable.")
if (ncol(dat) < 2) stop("The file needs a target column and at least one predictor.")

# Standardize column names for safe formula/model use, retaining original names
original_names <- names(dat)
names(dat) <- make.names(trimws(names(dat)), unique = TRUE)
name_map <- data.frame(original_name = original_names, usable_name = names(dat))
write.csv(name_map, file.path(OUTPUT_DIR, "column_name_mapping.csv"), row.names = FALSE)

cat("\n================ DATA OVERVIEW ================\n")
cat("Rows:", nrow(dat), " Columns:", ncol(dat), "\n")
cat("Columns:\n"); print(names(dat))
cat("\nStructure:\n"); print(str(dat))
cat("\nSummary:\n"); print(summary(dat))
write.csv(data.frame(column = names(dat),
                     class = vapply(dat, function(z) class(z)[1], character(1)),
                     missing_n = vapply(dat, function(z) sum(is.na(z)), integer(1))),
          file.path(OUTPUT_DIR, "data_quality_summary.csv"), row.names = FALSE)

# Locate target; the Word document alternates between BW and Weight.
target_candidates <- c("BW", "Weight", "BodyWeight", "Body_Weight")
target <- target_candidates[target_candidates %in% names(dat)][1]
if (is.na(target)) {
  stop("Could not identify target. Expected a column named BW or Weight (or BodyWeight). ",
       "Available columns: ", paste(names(dat), collapse = ", "))
}
cat("\nTarget selected:", target, "\n")
dat[[target]] <- suppressWarnings(as.numeric(as.character(dat[[target]])))
if (all(is.na(dat[[target]]))) stop("Target column could not be converted to numeric.")
dat <- dat[!is.na(dat[[target]]) & is.finite(dat[[target]]), , drop = FALSE]

# Dataset-specific correction:
# AN is an animal identifier and must not be a predictor; Sex is biological
# information and is retained as a categorical predictor.
if ("AN" %in% names(dat)) {
  dat <- dat[, names(dat) != "AN", drop = FALSE]
  cat("Excluded identifier column: AN; retained Sex as a predictor.\\n")
}

# Keep numeric predictors; convert character/factor predictors to factors.
for (nm in setdiff(names(dat), target)) {
  if (is.character(dat[[nm]]) || is.logical(dat[[nm]])) dat[[nm]] <- as.factor(dat[[nm]])
}
# Remove columns with only one unique non-missing value.
pred_names <- setdiff(names(dat), target)
constant <- pred_names[vapply(dat[pred_names], function(z) length(unique(z[!is.na(z)])) <= 1, logical(1))]
if (length(constant)) {
  cat("Removing constant predictor(s):", paste(constant, collapse = ", "), "\n")
  dat <- dat[, !names(dat) %in% constant, drop = FALSE]
}
pred_names <- setdiff(names(dat), target)
if (!length(pred_names)) stop("No predictors remain.")

# -------------------- 2. Split before analysis --------------------
set.seed(123)
idx <- caret::createDataPartition(dat[[target]], p = TRAIN_PROP, list = FALSE)
train_raw <- dat[idx, , drop = FALSE]
test_raw <- dat[-idx, , drop = FALSE]
if (nrow(test_raw) < 2) stop("Test set has fewer than two rows; dataset is too small.")

write.csv(train_raw, file.path(OUTPUT_DIR, "training_raw.csv"), row.names = FALSE)
write.csv(test_raw, file.path(OUTPUT_DIR, "test_raw.csv"), row.names = FALSE)
cat("\nTraining rows:", nrow(train_raw), " Test rows:", nrow(test_raw), "\n")

# ---------------- 3. Correlation analysis (training only) ----------
numeric_train <- train_raw[, vapply(train_raw, is.numeric, logical(1)), drop = FALSE]
if (ncol(numeric_train) >= 2) {
  cor_mat <- cor(numeric_train, use = "pairwise.complete.obs")
  write.csv(cor_mat, file.path(OUTPUT_DIR, "training_correlations.csv"))
  cor_long <- as.data.frame(as.table(cor_mat))
  names(cor_long) <- c("Variable1", "Variable2", "Correlation")
  p_cor <- ggplot(cor_long, aes(Variable1, Variable2, fill = Correlation)) +
    geom_tile() + scale_fill_gradient2(low = "blue", mid = "white", high = "red",
                                       midpoint = 0, limits = c(-1, 1)) +
    theme_minimal() + theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
    labs(title = "Training-set Pearson correlations", x = NULL, y = NULL)
  ggsave(file.path(OUTPUT_DIR, "training_correlation_heatmap.png"), p_cor,
         width = 9, height = 7, dpi = 300)
  cat("\nInterpretation: correlations near +1/-1 indicate strong linear association;\n",
      "they do not prove causation. Correlated predictors may contain redundant information.\n")
}

# Missing-value handling is learned from training data only.
# Numeric missing values: training median; categorical missing values: most frequent level.
mode_value <- function(z) {
  z <- z[!is.na(z)]
  if (!length(z)) return("Unknown")
  names(which.max(table(z)))[1]
}
impute_from_train <- function(train, test, target) {
  predictors <- setdiff(names(train), target)
  for (nm in predictors) {
    if (is.numeric(train[[nm]])) {
      med <- median(train[[nm]], na.rm = TRUE)
      if (!is.finite(med)) med <- 0
      train[[nm]][is.na(train[[nm]])] <- med
      test[[nm]][is.na(test[[nm]])] <- med
    } else {
      mv <- mode_value(as.character(train[[nm]]))
      tr <- as.character(train[[nm]]); te <- as.character(test[[nm]])
      tr[is.na(tr)] <- mv; te[is.na(te)] <- mv
      lev <- unique(c(tr, te, mv))
      train[[nm]] <- factor(tr, levels = lev)
      test[[nm]] <- factor(te, levels = lev)
    }
  }
  list(train = train, test = test)
}
imp <- impute_from_train(train_raw, test_raw, target)
train <- imp$train
test <- imp$test
pred_names <- setdiff(names(train), target)

# Remove any predictor that is still non-finite numeric.
bad <- pred_names[vapply(train[pred_names], function(z)
  is.numeric(z) && any(!is.finite(z)), logical(1))]
if (length(bad)) {
  warning("Removing predictors containing non-finite values: ", paste(bad, collapse = ", "))
  train <- train[, !names(train) %in% bad, drop = FALSE]
  test <- test[, !names(test) %in% bad, drop = FALSE]
}
pred_names <- setdiff(names(train), target)

# ------------------ 4. Feature selection: Boruta -------------------
selected_features <- pred_names
if (RUN_BORUTA && requireNamespace("Boruta", quietly = TRUE)) {
  # Boruta is run on training data only; test set is not used for selection.
  boruta_data <- train[, c(target, pred_names), drop = FALSE]
  set.seed(123)
  boruta_result <- tryCatch(
    Boruta::Boruta(stats::as.formula(paste(target, "~ .")),
                   data = boruta_data, doTrace = 0, maxRuns = 100),
    error = function(e) { message("Boruta failed: ", conditionMessage(e)); NULL }
  )
  if (!is.null(boruta_result)) {
    capture.output(print(boruta_result),
                   file = file.path(OUTPUT_DIR, "boruta_summary.txt"))
    boruta_stats <- Boruta::attStats(boruta_result)
    boruta_stats$Feature <- rownames(boruta_stats)
    write.csv(boruta_stats, file.path(OUTPUT_DIR, "boruta_importance.csv"), row.names = FALSE)
    png(file.path(OUTPUT_DIR, "boruta_importance.png"), width = 1200, height = 800, res = 140)
    plot(boruta_result, las = 2, main = "Boruta feature selection (training set)")
    dev.off()
    confirmed <- rownames(boruta_stats)[boruta_stats$decision == "Confirmed"]
    tentative <- rownames(boruta_stats)[boruta_stats$decision == "Tentative"]
    selected_features <- unique(c(confirmed, tentative))
    selected_features <- intersect(selected_features, pred_names)
    if (!length(selected_features)) {
      warning("Boruta did not confirm any predictors; using all predictors for model comparison.")
      selected_features <- pred_names
    }
    cat("\nBoruta selected/retained predictors:", paste(selected_features, collapse = ", "), "\n")
    cat("Interpretation: Confirmed predictors have importance above shadow features;\n",
        "Tentative predictors are uncertain. Importance is not a causal effect.\n")
  }
}
# Use the selected feature set consistently for fair comparison.
train_model <- train[, c(target, selected_features), drop = FALSE]
test_model <- test[, c(target, selected_features), drop = FALSE]

# CV folds: adapt to sample size; repeated hold-out is not substituted for test set.
folds <- min(CV_FOLDS, nrow(train_model))
if (folds < 2) stop("Not enough training rows for cross-validation.")
ctrl <- trainControl(method = "cv", number = folds,
                     savePredictions = "final", allowParallel = FALSE)

# ---------------------- 5. Metric helper --------------------------
reg_metrics <- function(actual, predicted) {
  ok <- is.finite(actual) & is.finite(predicted)
  actual <- actual[ok]; predicted <- predicted[ok]
  if (length(actual) < 2) return(c(RMSE = NA, MAE = NA, R2 = NA))
  rmse <- sqrt(mean((actual - predicted)^2))
  mae <- mean(abs(actual - predicted))
  denom <- sum((actual - mean(actual))^2)
  r2 <- if (denom > 0) 1 - sum((actual - predicted)^2) / denom else NA_real_
  c(RMSE = rmse, MAE = mae, R2 = r2)
}
results <- list()
predictions_out <- data.frame(Actual = test_model[[target]])
models <- list()
record_model <- function(name, model, pred) {
  m <- reg_metrics(test_model[[target]], as.numeric(pred))
  results[[name]] <<- data.frame(Model = name, RMSE = m["RMSE"], MAE = m["MAE"],
                                  R2 = m["R2"], stringsAsFactors = FALSE)
  predictions_out[[name]] <<- as.numeric(pred)
  models[[name]] <<- model
  cat("\n", name, " hold-out test metrics:\n", sep = "")
  print(round(m, 4))
}

# ------------------------- 6. Random Forest ------------------------
set.seed(123)
rf_fit <- train(stats::as.formula(paste(target, "~ .")), data = train_model,
                method = "rf", trControl = ctrl, tuneLength = 3,
                metric = "RMSE", preProcess = c("medianImpute"))
rf_pred <- predict(rf_fit, newdata = test_model)
record_model("Random Forest", rf_fit, rf_pred)
capture.output(print(rf_fit), file = file.path(OUTPUT_DIR, "random_forest_model.txt"))
rf_imp <- tryCatch(varImp(rf_fit), error = function(e) NULL)
if (!is.null(rf_imp)) {
  write.csv(rf_imp$importance, file.path(OUTPUT_DIR, "random_forest_importance.csv"))
  png(file.path(OUTPUT_DIR, "random_forest_importance.png"), 1000, 700, res = 130)
  print(plot(rf_imp, top = min(20, length(selected_features)),
             main = "Random Forest predictor importance"))
  dev.off()
}

# 
# --------------------------- 8. CART tree -------------------------
set.seed(123)
cart_fit <- train(stats::as.formula(paste(target, "~ .")), data = train_model,
                  method = "rpart", trControl = ctrl, tuneLength = 10,
                  metric = "RMSE", preProcess = c("medianImpute"))
cart_pred <- predict(cart_fit, newdata = test_model)
record_model("CART", cart_fit, cart_pred)
capture.output(print(cart_fit), file = file.path(OUTPUT_DIR, "cart_model.txt"))
png(file.path(OUTPUT_DIR, "cart_tree.png"), 1200, 900, res = 140)
plot(cart_fit$finalModel, uniform = TRUE, margin = 0.1)
text(cart_fit$finalModel, use.n = TRUE, cex = 0.7)
title("CART regression tree")
dev.off()

# ------------------------ 9. Neural network -----------------------
if (RUN_MLP && requireNamespace("nnet", quietly = TRUE)) {
  set.seed(123)
  mlp_fit <- tryCatch(
    train(stats::as.formula(paste(target, "~ .")), data = train_model,
          method = "nnet", trControl = ctrl, tuneLength = 3, metric = "RMSE",
          preProcess = c("center", "scale"), linout = TRUE, trace = FALSE,
          maxit = 500, MaxNWts = 10000),
    error = function(e) { message("Neural network skipped: ", conditionMessage(e)); NULL }
  )
  if (!is.null(mlp_fit)) {
    record_model("Neural Network (MLP)", mlp_fit, predict(mlp_fit, newdata = test_model))
    capture.output(print(mlp_fit), file = file.path(OUTPUT_DIR, "mlp_model.txt"))
  }
}

# --------------------- 10. Support Vector Machine -----------------
if (RUN_SVM && requireNamespace("kernlab", quietly = TRUE)) {
  set.seed(123)
  svm_fit <- tryCatch(
    train(stats::as.formula(paste(target, "~ .")), data = train_model,
          method = "svmRadial", trControl = ctrl, tuneLength = 5, metric = "RMSE",
          preProcess = c("center", "scale")),
    error = function(e) { message("SVM skipped: ", conditionMessage(e)); NULL }
  )
  if (!is.null(svm_fit)) {
    record_model("SVM Radial", svm_fit, predict(svm_fit, newdata = test_model))
    capture.output(print(svm_fit), file = file.path(OUTPUT_DIR, "svm_model.txt"))
  }
}

# ------------------------ 11. MARS regression ---------------------
if (RUN_MARS && requireNamespace("earth", quietly = TRUE)) {
  set.seed(123)
  mars_fit <- tryCatch(
    train(stats::as.formula(paste(target, "~ .")), data = train_model,
          method = "earth", trControl = ctrl, tuneLength = 5, metric = "RMSE"),
    error = function(e) { message("MARS skipped: ", conditionMessage(e)); NULL }
  )
  if (!is.null(mars_fit)) {
    record_model("MARS", mars_fit, predict(mars_fit, newdata = test_model))
    capture.output(print(mars_fit), file = file.path(OUTPUT_DIR, "mars_model.txt"))
  }
}

# --------------------- 12. Compare and interpret ------------------
results_df <- do.call(rbind, results)
results_df <- results_df[order(results_df$RMSE), ]
row.names(results_df) <- NULL
write.csv(results_df, file.path(OUTPUT_DIR, "model_comparison.csv"), row.names = FALSE)
write.csv(predictions_out, file.path(OUTPUT_DIR, "test_set_predictions.csv"), row.names = FALSE)

cat("\n================ MODEL COMPARISON ================\n")
print(transform(results_df,
                RMSE = round(as.numeric(RMSE), 4),
                MAE = round(as.numeric(MAE), 4),
                R2 = round(as.numeric(R2), 4)))
best <- results_df$Model[which.min(results_df$RMSE)]
cat("\nLowest test RMSE model:", best, "\n")
cat("Interpretation guide:\n",
    "* RMSE: typical error scale, with extra penalty for large errors; lower is better.\n",
    "* MAE: average absolute prediction error in the target's units; lower is better.\n",
    "* R2 here is 1 - SSE/SST on the hold-out set. It can be negative if predictions\n",
    "  are worse than predicting the test-set mean. Higher is better.\n",
    "* Compare RMSE/MAE only when models predict the same target in the same units.\n",
    "* Do not call the lowest-RMSE model 'best in general'; this is one hold-out split.\n")

# Actual-versus-predicted plot for the leading model.
best_pred <- predictions_out[[best]]
plot_df <- data.frame(Actual = test_model[[target]], Predicted = best_pred)
p_actual <- ggplot(plot_df, aes(x = Actual, y = Predicted)) +
  geom_point(alpha = 0.75) +
  geom_abline(intercept = 0, slope = 1, linetype = "dashed") +
  theme_minimal() +
  labs(title = paste("Actual vs predicted:", best),
       subtitle = "Points closer to the dashed line indicate more accurate predictions",
       x = paste("Observed", target), y = paste("Predicted", target))
ggsave(file.path(OUTPUT_DIR, "best_model_actual_vs_predicted.png"),
       p_actual, width = 7, height = 6, dpi = 300)

# Residual plot for leading model.
resid_df <- data.frame(Predicted = best_pred,
                       Residual = test_model[[target]] - best_pred)
p_resid <- ggplot(resid_df, aes(Predicted, Residual)) +
  geom_point(alpha = 0.75) + geom_hline(yintercept = 0, linetype = "dashed") +
  theme_minimal() +
  labs(title = paste("Residual plot:", best),
       x = "Predicted target", y = "Residual (observed - predicted)")
ggsave(file.path(OUTPUT_DIR, "best_model_residuals.png"),
       p_resid, width = 7, height = 6, dpi = 300)

# Human-readable workshop report with actual metrics.
report <- c(
  "ALAMBADI ML WORKSHOP — AUTOMATED RESULTS",
  paste("Input file:", DATA_FILE),
  paste("Target:", target),
  paste("Rows used:", nrow(dat)),
  paste("Training rows:", nrow(train_model), "| Test rows:", nrow(test_model)),
  paste("Predictors used:", paste(selected_features, collapse = ", ")),
  "",
  "MODEL COMPARISON (sorted by test RMSE):",
  capture.output(print(results_df, row.names = FALSE)),
  "",
  paste("Lowest RMSE on this test split:", best),
  "",
  "INTERPRETATION:",
  "RMSE and MAE are errors in the target's measurement units; lower is better.",
  "R2 = 1 - SSE/SST; it may be negative on unseen data.",
  "Feature importance indicates predictive contribution, not causality.",
  "The test metrics estimate generalization for this split; repeat validation or",
  "external validation is desirable before operational use.",
  "",
  "TEACHING DISCUSSION:",
  "1. Which model has the lowest test RMSE and MAE? Do they rank models similarly?",
  "2. Is test R2 positive? What would a negative value imply?",
  "3. Do important morphometric traits make biological sense?",
  "4. Could correlated traits, small sample size, missing values, or outliers affect results?",
  "5. Why must feature selection and tuning avoid the held-out test set?"
)
writeLines(report, file.path(OUTPUT_DIR, "workshop_interpretation.txt"))

cat("\nFiles written to:", normalizePath(OUTPUT_DIR), "\n")
cat("Open workshop_interpretation.txt and model_comparison.csv for teaching discussion.\n")
cat("Analysis complete.\n")
