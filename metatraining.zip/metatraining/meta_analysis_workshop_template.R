############################################################
# BIOINFORMATICS CENTRE WORKSHOP: META-ANALYSIS IN R
# Main pathway: continuous outcomes reported as mean, SD, n
# Packages: metafor; optional meta package for binary outcomes
############################################################

# 0. SET UP -------------------------------------------------
# If the downloaded data files are already in your working
# directory, check that R is looking in the correct folder.
getwd()
list.files()

# If necessary, set the working directory using RStudio:
# Session > Set Working Directory > Choose Directory
# Or uncomment and edit the next line:
# setwd("C:/your/path/to/your/data")  # Windows example
# setwd("/your/path/to/your/data")    # macOS/Linux example

# Install once only; do not run every time.
# install.packages("metafor")
# install.packages("meta")
# install.packages("readr")

library(metafor)

# 1. IMPORT YOUR FILE ---------------------------------------
# Change the filename to the exact file shown by list.files().
# For a CSV file:
dat_raw <- read.csv("your_data.csv", stringsAsFactors = FALSE)

# For an Excel file, install/load readxl and use:
# install.packages("readxl")
# library(readxl)
# dat_raw <- readxl::read_excel("your_data.xlsx", sheet = 1)

# 2. INSPECT THE DATA ---------------------------------------
names(dat_raw)
head(dat_raw)
str(dat_raw)
summary(dat_raw)
# Confirm one row per study and check missing values:
colSums(is.na(dat_raw))

# 3. PREPARE THE DATA ---------------------------------------
# The main example below expects these columns:
# study, n.e, mean.e, sd.e, n.c, mean.c, sd.c
#
# n.e / mean.e / sd.e = experimental/treatment group
# n.c / mean.c / sd.c = control/comparison group
#
# If your file uses different names, rename them before proceeding.
# Example:
# names(dat_raw)[names(dat_raw) == "Author"] <- "study"
# names(dat_raw)[names(dat_raw) == "N_treatment"] <- "n.e"
#
# Uncomment after confirming/renaming the columns:
# dat <- dat_raw[, c("study", "n.e", "mean.e", "sd.e",
#                    "n.c", "mean.c", "sd.c")]
#
# For a ready-to-use practice dataset, use the following
# illustrative data instead. This is synthetic teaching data,
# NOT evidence about a real treatment:
dat <- data.frame(
  study = c("Study A", "Study B", "Study C", "Study D",
            "Study E", "Study F", "Study G", "Study H"),
  n.e = c(42, 55, 38, 61, 47, 52, 40, 58),
  mean.e = c(14.2, 13.8, 15.1, 13.4, 14.0, 12.9, 14.7, 13.6),
  sd.e = c(4.2, 3.9, 4.5, 3.7, 4.1, 3.8, 4.4, 3.6),
  n.c = c(41, 53, 39, 60, 46, 50, 42, 57),
  mean.c = c(16.0, 15.1, 16.2, 15.5, 15.3, 14.8, 16.0, 15.0),
  sd.c = c(4.0, 4.1, 4.3, 3.9, 4.0, 4.2, 4.1, 3.8)
)

# If using your real dataset, replace the synthetic-data block
# above with the dat <- dat_raw[...] preparation block.

# Check that sample sizes are positive, SDs are positive,
# and all required numeric fields are present.
stopifnot(all(dat$n.e > 0), all(dat$n.c > 0))
stopifnot(all(dat$sd.e > 0), all(dat$sd.c > 0))
stopifnot(!anyNA(dat[, c("n.e", "mean.e", "sd.e",
                         "n.c", "mean.c", "sd.c")]))

# 4. CALCULATE EFFECT SIZES ---------------------------------
# SMD = standardized mean difference; escalc(measure="SMD")
# calculates Hedges' g and its sampling variance.
# Direction matters: m1i is treatment, m2i is control.
es <- escalc(
  measure = "SMD",
  m1i = mean.e, sd1i = sd.e, n1i = n.e,
  m2i = mean.c, sd2i = sd.c, n2i = n.c,
  data = dat,
  slab = study
)

# Inspect effect size (yi) and sampling variance (vi).
es[, c("study", "yi", "vi")]
# yi is Hedges' g; vi is its estimated sampling variance.
# Positive yi means treatment group mean is higher than control.
# Whether that is beneficial depends on how the outcome is coded.

# 5. FIT A RANDOM-EFFECTS MODEL -----------------------------
fit <- rma(yi, vi, data = es, method = "REML")
summary(fit)

# Read the output:
# - estimate: pooled Hedges' g
# - se: standard error of pooled effect
# - 95% CI: plausible range for the pooled effect
# - p-value: evidence against a pooled effect of zero
# - tau^2: estimated between-study variance
# - I^2: estimated proportion of observed variability attributable
#   to between-study heterogeneity rather than sampling error
# - Q test: tests whether effect sizes vary more than expected
#   from sampling error; interpret alongside I^2 and tau^2.

# 6. FOREST PLOT --------------------------------------------
forest(
  fit,
  slab = es$study,
  xlab = "Hedges' g (standardized mean difference)",
  refline = 0
)
# Each horizontal line is a study's confidence interval.
# The pooled diamond/summary estimate represents the model estimate.
# The vertical line at 0 means no standardized mean difference.

# Save a copy to the working directory:
pdf("forest_plot.pdf", width = 8, height = 7)
forest(fit, slab = es$study,
       xlab = "Hedges' g (standardized mean difference)",
       refline = 0)
dev.off()

# 7. HETEROGENEITY AND PREDICTION INTERVAL ------------------
fit$tau2
fit$I2
fit$QE
fit$QEp
predict(fit)
# A prediction interval estimates the range in which the true effect
# of a comparable new study might lie; it is not the CI for the mean.

# 8. FUNNEL PLOT AND SMALL-STUDY EFFECTS --------------------
funnel(fit, xlab = "Hedges' g")
# Visual asymmetry can have several causes; it does not prove
# publication bias. Tests have low power when few studies are present.
if (fit$k >= 10) {
  regtest(fit, model = "rma")
} else {
  message("Fewer than 10 studies: treat funnel plot/test cautiously.")
}

# 9. SENSITIVITY / INFLUENCE --------------------------------
leave1out(fit)
inf <- influence(fit)
print(inf)
plot(inf)
# Ask whether the pooled result changes substantially when one study
# is removed, and whether any study appears unusually influential.

# 10. OPTIONAL SUBGROUP / META-REGRESSION --------------------
# Only run if your file contains a meaningful study-level moderator,
# e.g. setting or risk_of_bias, with enough studies per category.
# Add the moderator to dat before escalc(), then:
# fit_mod <- rma(yi, vi, mods = ~ moderator, data = es, method = "REML")
# summary(fit_mod)
# Categorical moderators should be factors; do not interpret
# observational moderator associations as causal effects.

# 11. SAVE ANALYSIS OBJECT AND TABLE -------------------------
saveRDS(fit, file = "meta_analysis_model.rds")
write.csv(data.frame(
  study = es$study,
  effect_size = es$yi,
  sampling_variance = es$vi
), "study_effect_sizes.csv", row.names = FALSE)

# 12. BINARY OUTCOMES: STARTING POINT ONLY -------------------
# If the studies report events and totals instead of means/SDs,
# do NOT use the continuous-outcome workflow above.
# Expected columns: study, event.e, n.e, event.c, n.c.
# Example after preparing those columns:
#
# library(meta)
# m_bin <- metabin(
#   event.e = event.e, n.e = n.e,
#   event.c = event.c, n.c = n.c,
#   studlab = study, data = dat_binary,
#   sm = "RR", method = "MH",
#   common = FALSE, random = TRUE,
#   method.tau = "REML"
# )
# summary(m_bin)
# forest(m_bin)
#
# For RR/OR, the null value is 1 (not 0). Check the installed
# meta package help if argument names differ in an older version.

############################################################
# END: Use the synthetic example first, then substitute your data.
############################################################
