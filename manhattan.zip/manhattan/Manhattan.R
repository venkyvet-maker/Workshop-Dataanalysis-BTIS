#plink --bfile toda_qc_final --pheno milkfat_pheno.txt --pheno-name MilkFat --covar covar1.txt --covar-name Parity,LactationStage,Herd --linear hide-covar --allow-no-sex --chr-set 24 --out milkfat_assoc_covar1


#QQ plot for SCS
library(qqman)



# Read the SCS association annotation file
assoc_scs <- read.csv(
  "scs_assoc_covar1_final_annotation_table.csv",
  header = TRUE,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

# Check column names
names(assoc_scs)

# Extract and clean P-values
p_values_scs <- as.numeric(assoc_scs$P)

p_values_scs <- p_values_scs[
  !is.na(p_values_scs) &
  p_values_scs > 0 &
  p_values_scs <= 1
]

# Display the Q–Q plot in R
qq(
  p_values_scs,
  main = "Q–Q Plot for Somatic Cell Score"
)

# Save as high-resolution TIFF
tiff(
  filename = "SCS_QQ_plot.tiff",
  width = 7,
  height = 7,
  units = "in",
  res = 600,
  compression = "lzw"
)

qq(
  p_values_scs,
  main = "Q–Q Plot for Somatic Cell Score"
)
dev.off()
# Confirm that the file was saved
file.exists("SCS_QQ_plot.tiff")


# Read and filter PLINK results
assoc <- read.table("milkfat_assoc_covar1.assoc.linear", header=TRUE)
assoc <- subset(assoc, TEST=="ADD" & !is.na(P) & P>0 & P<=1)
assoc$CHR <- as.numeric(assoc$CHR)
assoc$BP  <- as.numeric(assoc$BP)

# Significance thresholds
bonf.p <- 8.82e-7
suggestive.p <- 1e-5

# Save Manhattan plot
png("MilkFat_Manhattan_Bonferroni.png", width=4500, height=2500, res=300)

manhattan(assoc, chr="CHR", bp="BP", snp="SNP", p="P",
          main="GWAS for Milk Fat Percentage",
          col=c("dodgerblue4","darkorange"),
          genomewideline=-log10(bonf.p),
          suggestiveline=-log10(suggestive.p),
          ylim=c(0, max(-log10(assoc$P))+0.5),
          cex=0.6)

dev.off()

# Display plot in R
manhattan(assoc, chr="CHR", bp="BP", snp="SNP", p="P",
          main="GWAS for Milk Fat Percentage",
          col=c("dodgerblue4","darkorange"),
          genomewideline=-log10(bonf.p),
          suggestiveline=-log10(suggestive.p),
          ylim=c(0, max(-log10(assoc$P))+0.5),
          cex=0.6)
